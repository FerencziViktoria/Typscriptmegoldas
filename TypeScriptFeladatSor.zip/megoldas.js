"use strict";
//1.feladat
//function DiakInfo(nev: string, csoport: number, tipus: boolean):[string]{}
//2. feladat
function Erdemjegy(jegy) {
    if (jegy == 5) {
        return "Példás, Példás";
    }
    else if (jegy == 4) {
        return "Jó, Jó";
    }
    else if (jegy == 3) {
        return "Változó, Változó";
    }
    else if (jegy == 2) {
        return "Hanyag, Rossz";
    }
}
let kapottJegy = Erdemjegy(2);
console.log("A kapott érdemjegy: " + kapottJegy);
//3. feladat
var vizsgaltTomb = [10, 23, 12, 24, 31, 33, 42, 20];
function HarommalOszthatokSzama(vizsgaltTomb) {
    let oszthatokSzama = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 3 == 0) {
            oszthatokSzama++;
        }
    }
    return oszthatokSzama;
}
console.log("A tömbben lévő hárommal osztható elemek száma:" + HarommalOszthatokSzama(vizsgaltTomb));
//4. feladat
function RandomSzamGenerator(alsoHatar, felsoHatar) {
    return Math.round(Math.random() * (felsoHatar - alsoHatar) + alsoHatar);
}
function Nyeroszamok(mennyiseg, alsoHatar, felsoHatar) {
    let generaltTomb = [];
    for (let i = 0; i < mennyiseg; i++) {
        generaltTomb.push(RandomSzamGenerator(alsoHatar, felsoHatar) + alsoHatar);
        let szerepelE = false;
        for (let j = 0; j < generaltTomb.length; j++) {
            if (generaltTomb[i] == generaltTomb[j]) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            generaltTomb.push(generaltTomb[i]);
        }
    }
    return generaltTomb;
}
var nyeroTomb = Nyeroszamok(5, 1, 90);
console.log(nyeroTomb);
